﻿---
description: Проанализировать проект и создать системные требования Delion.
---

Проанализируй текущий проект и создай системные требования Delion.

Выполни:

```powershell
python "%USERPROFILE%\.gigacode\extensions\delion\main.py" --project-root "%CD%" \deli:init
```

После выполнения покажи путь к файлу `docs/system-requirements.md` и явно скажи, что файл должен быть проверен и дополнен человеком перед использованием оркестратора.
